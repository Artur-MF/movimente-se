/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{
    int n1, n2;
    printf("Digite dois números: ");
    scanf("%i%i", &n1, &n2);
    
    if(n1>n2){
        printf("O primeiro valor é maior");
    }
    else if(n1<n2){
        printf("O Segundo valor é maior");
    } else{
        printf("Ambos são iguais.");
    }

    
}