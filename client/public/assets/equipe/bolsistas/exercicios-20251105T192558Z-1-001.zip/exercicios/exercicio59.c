#include <stdio.h>

int main()
{
    char sexo;
    int maiorIdade, mediaIdadeHomens, numHomens, somaIdadeHomens, idadeMulherMaisJovem, idade, continuar;

    maiorIdade = 0;
    numHomens = 0;
    somaIdadeHomens = 0;
    continuar = 1;
    idadeMulherMaisJovem = 0;

    printf("Digite a idade: ");
    scanf("%i", &idade);

    printf("Digite o sexo (M/F): ");
    scanf(" %c", &sexo);

    maiorIdade = idade;

    if (sexo == 'M' || sexo == 'm')
    {
        numHomens = 1;
        somaIdadeHomens = idade;
    }
    else if (sexo == 'F' || sexo == 'f')
    {
        numHomens = 0;
        somaIdadeHomens = 0;
        idadeMulherMaisJovem = idade;
    }
    else
    {
        numHomens = 0;
        somaIdadeHomens = 0;
    }

    printf("Deseja continuar? (S/N): ");
    scanf(" %c", &continuar);

    while (continuar == 'S' || continuar == 's')
    {
        printf("Digite a idade: ");
        scanf("%d", &idade);

        printf("Digite o sexo (M/F): ");
        scanf(" %c", &sexo);

        if (idade > maiorIdade)
        {
            maiorIdade = idade;
        }

        // Atualizar contadores e acumuladores
        if (sexo == 'M' || sexo == 'm')
        {
            numHomens++;
            somaIdadeHomens += idade;
        }
        else if (sexo == 'F' || sexo == 'f')
        {
            if (idadeMulherMaisJovem == 0 || idade < idadeMulherMaisJovem)
            {
                idadeMulherMaisJovem = idade;
            }
        }

        printf("Deseja continuar? (S/N): ");
        scanf(" %c", &continuar);
    }

    printf("\n--- RESULTADOS ---\n");
    printf("a) Maior idade lida: %d\n", maiorIdade);
    printf("b) Número de homens cadastrados: %d\n", numHomens);

    if (idadeMulherMaisJovem != 0)
    {
        printf("c) Idade da mulher mais jovem: %d\n", idadeMulherMaisJovem);
    }
    else
    {
        printf("c) Nenhuma mulher foi cadastrada.\n");
    }

    if (numHomens > 0)
    {
         mediaIdadeHomens = somaIdadeHomens / numHomens;
        printf("d) Média de idade entre os homens: %i\n", mediaIdadeHomens);
    }
    else
    {
        printf("d) Nenhum homem foi cadastrado.\n");
    }

    return 0;
}
