/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double reais, dolar;
    
    printf("Digite um valor em reais: \n");
    scanf("%lf", &reais);
    
    dolar = reais/3.45;
    
    printf("Você pode comprar U$ %lf dolares", dolar);
    
    




    return 0;
    
}