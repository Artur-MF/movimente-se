#include <stdio.h>
#include <locale.h>

int main(){
    int i, numero;
    printf("Digite um númerop ara saber a tabuada: ");
    scanf("%i", &numero);


    for (i = 1; i<=10; i++) {
    printf("%i x %i = %i\n", numero, i, i*numero);
} 
}