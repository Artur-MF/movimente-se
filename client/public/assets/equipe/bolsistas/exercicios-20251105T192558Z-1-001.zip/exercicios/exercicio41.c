#include <stdio.h>
#include <locale.h>

int main(){
    int contagem;
    contagem = 100;
    while(contagem>=0){
        printf("%i\n", contagem);
        contagem -= 5;
    }
    printf("Acabou");
}