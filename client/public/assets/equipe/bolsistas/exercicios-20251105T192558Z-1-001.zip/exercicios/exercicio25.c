/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{
    double km, r1, r2, r3;
    printf("Digite o valor de três segmentos de retas: ");
    scanf("%lf%lf%lf", &r1, &r2, &r3);
    
    if((r1+r2) > r3 && (r1+r3) > r2 && (r3+r2) > r1){
        printf("Pode formar um triângulo");
        
    } else{
        printf("Não pode formar um triângulo.");
    }

    
}