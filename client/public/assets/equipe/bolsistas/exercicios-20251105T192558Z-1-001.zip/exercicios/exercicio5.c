/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double n1, n2, media;
    
    printf("Digite as duas notas: \n");
    scanf("%lf %lf", &n1, &n2);
    media = (n1+n2)/2;
    
    printf("A media das nota é: %lf", media);



    return 0;
    
}