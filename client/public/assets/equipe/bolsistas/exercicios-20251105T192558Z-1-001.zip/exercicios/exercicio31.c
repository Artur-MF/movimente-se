/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{


     int j1, j2;


    printf("Escolha:\n1 - Pedra\n2 - Papel\n3 - Tesoura\n");


    printf("Jogador 1, escolha: ");
    scanf("%d", &j1);


    printf("Jogador 2, escolha: ");
    scanf("%d", &j2);


    if (j1 < 1 || j1 > 3 || j2 < 1 || j2 > 3) {
        printf("Escolha inválida de um dos jogadores.\n");
    }

    if (j1 == j2) {
        printf("Empate!\n");
    } else if ((j1 == 1 && j2 == 3) ||
               (j1 == 2 && j2 == 1) ||
               (j1 == 3 && j2 == 2)) {
        printf("Jogador 1 venceu!\n");
    } else {
        printf("Jogador 2 venceu!\n");
    }

    


}