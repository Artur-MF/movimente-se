/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double salario, aumento;
    
    printf("Digite o valor do salário:\n");
    scanf("%lf", &salario);
    
    aumento = salario*1.15;

    
    printf("O Valor do novo salário é: R$ %.2lf", aumento);
    
    




    return 0;
    
}