#include <stdio.h>
#include <locale.h>

int main()
{
    int i, mulheresCadastradas, HomensAcima100Kg, QuantidadeMulheres, MediaPesoMulheres, MaiorPesoHomem;
    double peso, PesoMulheres;
    char sexo;
    mulheresCadastradas = 0;
    HomensAcima100Kg = 0;
    QuantidadeMulheres = 0;
    MediaPesoMulheres = 0;
    MaiorPesoHomem = 0;
    PesoMulheres = 0;

    for (i = 1; i <= 8; i++)
    {
        printf("Digite seu Sexo: ");
        scanf(" %c", &sexo);

        printf("Digite seu peso:");
        scanf("%lf", &peso);

        if (sexo == 'M' || sexo == 'm')
        {
            HomensAcima100Kg++;
            if (peso > MaiorPesoHomem)
            {
                MaiorPesoHomem = peso;
            }
        }

        else if (sexo == 'F' || sexo == 'f')
        {
            mulheresCadastradas++;
            PesoMulheres += peso;
        }
    }

    MediaPesoMulheres = PesoMulheres / mulheresCadastradas;

    printf("a) Quantas mulheres foram cadastradas: %i\n", mulheresCadastradas);
    printf("b) Quantos homens pesam mais de 100Kg: %i\n", HomensAcima100Kg);
    printf("c) A média de peso entre as mulheres: %i\n", MediaPesoMulheres);
    printf("d) O maior peso entre os homens: %i\n", MaiorPesoHomem);
}