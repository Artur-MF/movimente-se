#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int contagem, somador;
    contagem = 500;
    somador = 0;

    while (contagem >= 0)
    {
        somador += contagem;
        contagem-=50;

    }
    printf("A soma de tudo é: %i", somador);
}