/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double a, b, c, delta;
    
    printf("Digite o valor de a:\n");
    scanf("%lf", &a);
    
    printf("Digite o valor de b:\n");
    scanf("%lf", &b);
    
    printf("Digite o valor de c:\n");
    scanf("%lf", &c);
    
    delta = (b*b) -4*a*c;
    
    printf("O Valor de delta é %lf", delta);
    
    




    return 0;
    
}