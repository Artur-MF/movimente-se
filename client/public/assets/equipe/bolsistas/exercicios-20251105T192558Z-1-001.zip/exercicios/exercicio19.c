/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
 
    double n1, n2, media;
    char nome[20];
    
    printf("Digite o nome do aluno: ");
    scanf("%s", nome);
    
    printf("Digite as notas do aluno: ");
    scanf("%lf%lf", &n1, &n2);
    
    media = (n1+n2)/2;
    
    if (media >= 7.0){
        printf("O Aluno teve um bom aproveitamento!");
    } else{
        printf("Não teve um bom aproveitamento!");
    }
    

}