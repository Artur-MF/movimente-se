/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double produto, promocao;
    
    printf("Digite o valor do produto:\n");
    scanf("%lf", &produto);
    
    promocao = produto - produto*0.05;

    
    printf("O Valor do produto na promoção é: R$ %.2lf", promocao);
    
    




    return 0;
    
}