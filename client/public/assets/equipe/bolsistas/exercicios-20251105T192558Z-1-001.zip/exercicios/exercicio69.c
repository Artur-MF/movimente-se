#include <stdio.h>
#include <locale.h>

int main()
{
    int n, razao, a_1, somatorio, PA;
    somatorio = 0;

    printf("Digite o primeiro termo de PA: \n");
    scanf("%i", &a_1);

    printf("Digite o número da razao: \n");
    scanf("%i", &razao);

    for (n = 1; n <= 10; n++)
    {

        PA = a_1 + (n - 1) * razao;
        somatorio += PA;
    }

    printf("%i", somatorio);
}