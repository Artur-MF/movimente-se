#include <stdio.h>
#include <locale.h>

int main(){
    int contagem;
    contagem = 6;
    while(contagem<=11){
        printf("%i\n", contagem);
        contagem++;
    }
    printf("Acabou");
}