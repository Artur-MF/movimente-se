#include <stdio.h>
#include <locale.h>

int main(){
    int i;
    for (i =0; i<=9; i++) {
    printf("%i\n", i);
} 
printf("FIM!");
}