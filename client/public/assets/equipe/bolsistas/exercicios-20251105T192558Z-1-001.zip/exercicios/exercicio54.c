#include <stdio.h>

int main() {
    float altura, peso;
    int contador = 0;
    int contadorPeso90 = 0;
    int contadorPeso50Altura160 = 0;
    int contadorAltura190Peso100 = 0;
    float somaAltura = 0;
    
    while (contador < 7) {
        printf("Digite o peso da pessoa %d (kg): ", contador + 1);
        scanf("%f", &peso);
        printf("Digite a altura da pessoa %d (m): ", contador + 1);
        scanf("%f", &altura);
        

        somaAltura += altura;


        if (peso > 90) {
            contadorPeso90++;
        }

        if (peso < 50 && altura < 1.60) {
            contadorPeso50Altura160++;
        }


        if (altura > 1.90 && peso > 100) {
            contadorAltura190Peso100++;
        }

        contador++;  
    }

    float mediaAltura = somaAltura / 7;
    printf("\nMédia de altura do grupo: %.2f metros\n", mediaAltura);

    printf("Número de pessoas que pesam mais de 90kg: %d\n", contadorPeso90);

    printf("Número de pessoas que pesam menos de 50kg e têm menos de 1.60m: %d\n", contadorPeso50Altura160);

    printf("Número de pessoas que medem mais de 1.90m e pesam mais de 100kg: %d\n", contadorAltura190Peso100);

    return 0;
}
