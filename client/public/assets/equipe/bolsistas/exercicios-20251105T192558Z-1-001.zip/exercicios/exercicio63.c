#include <stdio.h>
#include <locale.h>

int main()
{
    int i, numerosDigitados, menorNumero, numerosPares, mediaNumeros, numero, numerosSomados, verifica;
    numerosDigitados = 0;
    numerosSomados = 0;

    printf("Digite um número: ");
    scanf("%i", &numero);
    numerosDigitados++;
    numerosSomados += numero;
    menorNumero = numero;
    numerosPares = 0;

    if (numero % 2 == 0)
    {
        numerosPares++;
    }

    printf("Deseja continuar o programa? \n 1. Sim \n 0. Não");
    scanf("%i", &verifica);



    for (i = verifica; i != 0; i++)
    {
        printf("Digite um número: ");
        scanf("%i", &numero);
        numerosDigitados++;
        numerosSomados += numero;

        if (numero < menorNumero)
        {
            menorNumero = numero;
        }

        if (numero % 2 == 0)
        {
            numerosPares++;
        }

        printf("Deseja continuar o programa? \n 1. Sim \n 0. Não");
        scanf("%i", &verifica);

        if (verifica == 0)
        {
            break;
        }
    }
    mediaNumeros = numerosSomados / numerosDigitados;

    printf("a) O somatório entre todos os valores:  %i\n", numerosSomados);
    printf("b) Qual foi o menor valor digitado: %i\n", menorNumero);
    printf("c) A média entre todos os valores: %i\n", mediaNumeros);
    printf("d) Quantos valores são pares: %i\n", numerosPares);
}