#include <stdio.h>
#include <locale.h>

int main(){
    int contagem;
    contagem = 0;
    while(contagem <= 18){
        printf("%i\n", contagem);
        contagem += 3;
    }
    printf("Acabou");
}