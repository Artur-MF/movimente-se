/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{
    double altura, comprimento, area;
    printf("Digite a altura e o comprimento respectivamente: ");
    scanf("%lf%lf", &altura, &comprimento);
    
    area = altura*comprimento;
    
    if(area<100){
        printf("Terreno Popular!");
    }
    else if(area<500){
        printf("Terreno Master");
    } else{
        printf("Terreno Vip");
    }

    
}