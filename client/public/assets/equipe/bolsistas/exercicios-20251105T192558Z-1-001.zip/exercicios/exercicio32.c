
#include <stdio.h>
#include <stdlib.h>


int main()
{


    int jogador, sorteio;
    sorteio = rand() % 10 + 1;
    printf("Digite um número para acertar o número sorteado: ");
    scanf("%i", &jogador);
    
    if (jogador == sorteio){
        printf("Acertou!");
    } else{
        printf("Errou! o número correto era: %i ", sorteio);
    }


    


}