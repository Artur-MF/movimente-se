#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int contagem, somador;
    contagem = 6;
    somador = 0;

    while (contagem <= 101)
    {
        somador += contagem;
        contagem+=2;

    }
    printf("A soma de tudo é: %i", somador);
}