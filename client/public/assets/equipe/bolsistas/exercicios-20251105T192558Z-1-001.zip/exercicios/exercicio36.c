/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/



#include <stdio.h>
#include <stdlib.h>


int main() {
    double horas, pontos, dinheiro;

    system("cls");
    printf("Digite a quantidade de horas de atividade no mês: ");
    scanf("%lf", &horas);

    if (horas <= 10) {
        pontos = horas * 2;
    } else if (horas <= 20) {
        pontos = horas * 5;
    } else {
        pontos = horas * 10;
    }

    dinheiro = pontos * 0.05;

    printf("Pontos ganhos: %.2lf\n", pontos);
    printf("Dinheiro ganho: R$ %.2lf\n", dinheiro);

}