#include <stdio.h>
#include <locale.h>

int main(){
    int i;
    for (i = 100; i>=0; i = i -10) {
    printf("%i\n", i);
} 
printf("Acabou!");
}