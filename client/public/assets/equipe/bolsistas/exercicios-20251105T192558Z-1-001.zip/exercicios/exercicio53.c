#include <stdio.h>

int main() {
    int idade, homens, mulheres, somaIdades, somaIdadesHomens, mulheresMais20;
    char sexo;
    int contador = 0;
    homens = 0;
    mulheres = 0;
    somaIdades = 0;
    somaIdadesHomens = 0;
    mulheresMais20 = 0;

    while (contador < 5) {
        printf("Digite a idade: ");
        scanf("%i", &idade);

        printf("Digite o sexo (M/F): ");
        scanf(" %c", &sexo);

        somaIdades += idade;

        if (sexo == 'M' || sexo == 'm') {
            homens++;
            somaIdadesHomens += idade;
        } else if (sexo == 'F' || sexo == 'f') {
            mulheres++;
            if (idade > 20) {
                mulheresMais20++;
            }
        }

        contador++;
    }

    printf("Homens cadastrados: %i\n", homens);
    printf("Mulheres cadastradas: %i\n", mulheres);
    printf("Media de idade do grupo: %.2f\n", somaIdades / 5.0);

    if (homens > 0) {
        printf("Media de idade dos homens: %.2f\n", somaIdadesHomens /homens);
    } else {
        printf("Nenhum homem cadastrado.\n");
    }

    printf("Mulheres com mais de 20 anos: %i\n", mulheresMais20);

}
