#include <stdio.h>
#include <locale.h>

int main(){
    int i, idadesDigitadas, mediaIdades, idade ,idadeSomadas, idadeMaiorQue21, verifica;
    idadesDigitadas = 0;
    idadeSomadas = 0;
    idadeMaiorQue21 = 0;



    for (i = 1; i!=0; i++) {
    printf("Digite a idade: ");
    scanf("%i", &idade);
    idadesDigitadas++;
    idadeSomadas+=idade;

    if(idade>=21){
        idadeMaiorQue21++;
    }

    printf("Deseja continuar o programa? \n 1. Sim \n 0. Não");
    scanf("%i", &verifica);

    if(verifica==0){
        break;
    }
} 
mediaIdades = idadeSomadas/idadesDigitadas;

printf("a) Quantas idades foram digitadas: %i\n", idadesDigitadas);
printf("b) Qual é a média entre as idades digitadas: %i\n", mediaIdades);
printf("c) Quantas pessoas tem 21 anos ou mais: %i\n", idadeMaiorQue21);




}