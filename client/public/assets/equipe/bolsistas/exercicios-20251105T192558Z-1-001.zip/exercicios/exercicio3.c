/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    char nome[100];
    float salario;
    
    printf("Qual seu nome?\n");
    scanf("%s", nome);
    
    printf("Qual o salário? \n");
    scanf("%f", &salario);
    
    printf("O Funcionário %s tem um salario de: R$ %1.f", nome, salario);


    return 0;
    
}