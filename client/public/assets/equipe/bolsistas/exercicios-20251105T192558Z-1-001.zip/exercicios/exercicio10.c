/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double altura, largura, area;
    
    printf("Digite a largura da parede:\n");
    scanf("%lf", &largura);
    
    printf("Digite a altura da parede:\n");
    scanf("%lf", &altura);
    
    area = largura*altura;
    
    printf("Você vai pintar uma área de %lf metros quadrados e vai precisar de %lf litros de tinta", area, area/2);
    
    




    return 0;
    
}