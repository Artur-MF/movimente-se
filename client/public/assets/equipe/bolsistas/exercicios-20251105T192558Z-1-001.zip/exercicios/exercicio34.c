/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>


int main()
{

#include <stdio.h>

    double peso, altura, imc;

    printf("Digite seu peso (kg): ");
    scanf("%lf", &peso);

    printf("Digite sua altura (m): ");
    scanf("%lf", &altura);

    imc = peso/(altura*altura);

    printf("\nSeu IMC é: %.2lf\n", imc);

    if (imc < 18.5) {
        printf("Classificação: Abaixo do peso\n");
    } 
    else if (imc < 25) {
        printf("Classificação: Peso ideal\n");
    } 
    else if (imc < 30) {
        printf("Classificação: Sobrepeso\n");
    } 
    else if (imc < 40) {
        printf("Classificação: Obesidade\n");
    } else {
        printf("Classificação: Obesidade mórbida\n");
    }


}