#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>

int main()
{

    system("cls");
    srand(time(NULL));

    int contagem;
    double valor, maior, menor;

    contagem = 1;

    printf("Digite o valor de um produto: ");
    scanf("%lf", &valor);

    maior = valor;
    menor = valor;

    while (contagem < 8)
    {
        contagem++;
        printf("Digite o valor de um produto: ");
        scanf("%lf", &valor);

        if (valor > maior)
        {
            maior = valor;
        }

        else if (valor < menor)
        {
            menor = valor;
        }
    }

    printf("Maior valor: %.2lf \n", maior);
    printf("Menor valor: %.2lf \n", menor);
}