#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int contagem;
    contagem = 30;
    while (contagem >= 1)
    {
        if (contagem % 4 == 0)
        {
            printf("|%i|\n", contagem);
            contagem--;
        }
        else
        {
            printf("%i\n", contagem);
            contagem--;
        }
    }
    printf("Acabou");
}