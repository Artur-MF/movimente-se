#include <stdio.h>
#include <string.h> // necessário para strcpy

int main()
{
    char sexo, continuar;
    int maiorIdade = 0, mediaIdade, numPessoas = 0, numMulherMenorQue18 = 0, numHomensMaiorQue30 = 0;
    int somaIdades = 0, idadeMulherMaisJovem = 0, idade;
    char pessoaMaisVelha[50] = "", nome[50], nomeMulherMaisJovem[50] = "";

    // Ler a primeira pessoa
    printf("Digite seu nome: \n");
    scanf("%s", nome);

    printf("Digite a idade: ");
    scanf("%i", &idade);

    printf("Digite o sexo (M/F): ");
    scanf(" %c", &sexo);

    maiorIdade = idade;
    strcpy(pessoaMaisVelha, nome);

    if ((sexo == 'M' || sexo == 'm') && idade > 30)
    {
        numHomensMaiorQue30 = 1;
    }
    else if ((sexo == 'F' || sexo == 'f') && idade < 18)
    {
        numMulherMenorQue18 = 1;
        idadeMulherMaisJovem = idade;
        strcpy(nomeMulherMaisJovem, nome);
    }

    somaIdades = idade;
    numPessoas = 1;

    printf("Deseja continuar? (S/N): ");
    scanf(" %c", &continuar);

    while (continuar == 'S' || continuar == 's')
    {
        printf("Digite o nome: \n");      // faltava ler o nome no loop
        scanf("%s", nome);

        printf("Digite a idade: ");
        scanf("%d", &idade);

        printf("Digite o sexo (M/F): ");
        scanf(" %c", &sexo);

        somaIdades += idade;
        numPessoas++;

        if (idade > maiorIdade)
        {
            maiorIdade = idade;
            strcpy(pessoaMaisVelha, nome);
        }

        // Atualizar mulher mais jovem
        if ((sexo == 'F' || sexo == 'f'))
        {
            if (idadeMulherMaisJovem == 0 || idade < idadeMulherMaisJovem)
            {
                idadeMulherMaisJovem = idade;
                strcpy(nomeMulherMaisJovem, nome);
            }
        }

        if ((sexo == 'M' || sexo == 'm') && idade > 30)
        {
            numHomensMaiorQue30++;
        }
        else if ((sexo == 'F' || sexo == 'f') && idade < 18)
        {
            numMulherMenorQue18++;
        }

        printf("Deseja continuar? (S/N): ");
        scanf(" %c", &continuar);
    }

    mediaIdade = somaIdades / numPessoas;

    printf("\n--- RESULTADOS ---\n");
    printf("a) O nome da pessoa mais velha: %s\n", pessoaMaisVelha);

    if (idadeMulherMaisJovem > 0)
        printf("b) O nome da mulher mais jovem: %s\n", nomeMulherMaisJovem);
    else
        printf("b) Nenhuma mulher cadastrada.\n");

    printf("c) A média de idade do grupo: %i \n", mediaIdade);
    printf("d) Quantos homens tem mais de 30 anos: %i\n", numHomensMaiorQue30);
    printf("e) Quantas mulheres tem menos de 18 anos: %i\n", numMulherMenorQue18);

    return 0;
}
