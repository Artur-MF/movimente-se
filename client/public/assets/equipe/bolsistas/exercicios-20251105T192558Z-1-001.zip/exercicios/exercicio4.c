/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double n1, n2, total;
    
    printf("Digite dois numeros?\n");
    scanf("%lf %lf", &n1, &n2);
    total = n1+n2;
    
    printf("A soma entre %lf e %lf é: %lf", n1, n2, total);



    return 0;
    
}