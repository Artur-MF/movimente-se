/******************************************************************************



Welcome to GDB Online.

GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/



#include <stdio.h>


#include <stdio.h>

int main() {
    double salario, novoSalario;
    char genero;
    int anos;

    printf("Digite o salário atual: ");
    scanf("%lf", &salario);

    printf("Digite o gênero (M/F): ");
    scanf(" %c", &genero);

    printf("Digite há quantos anos trabalha na empresa: ");
    scanf("%d", &anos);

    if (genero == 'F' || genero == 'f') {
        if (anos < 15) {
            novoSalario = salario * 1.05;
        } 
        else if (anos <= 20) {
            novoSalario = salario * 1.12;
        } else {
            novoSalario = salario * 1.23;
        }
    } else if (genero == 'M' || genero == 'm') {
        if (anos < 20) {
            novoSalario = salario * 1.03;
        } 
        else if (anos <= 30) {
            novoSalario = salario * 1.13;
        } else {
            novoSalario = salario * 1.25;
        }
    } else {
        printf("Gênero inválido.\n");
    }

    printf("Novo salário: R$ %.2lf\n", novoSalario);

}


