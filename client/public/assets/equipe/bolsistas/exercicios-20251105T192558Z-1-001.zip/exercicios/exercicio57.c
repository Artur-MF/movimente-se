// 57. Desenvolva um aplicativo que leia o salário e o sexo de vários funcionários. No final,
// mostre o total de salários pagos aos homens e o total pago às mulheres. O programa vai
// perguntar ao usuário se ele quer continuar ou não sempre que ler os dados de um
// funcionário.

#include <stdio.h>
#include <string.h>

int main()
{
    double salario, salariosHomens, salariosMulheres;
    char sexo;
    int verifica;
    salariosHomens = 0;
    salariosMulheres = 0;
    verifica = 1;

    while (verifica != 2)
    {
        printf("Digite um Salário: \n");
        scanf("%lf", &salario);

        printf("Digite o sexo do funcionário: \n");
        scanf(" %c", &sexo);

        if (sexo == 'M' || sexo == 'm')
        {
            salariosHomens += salario;
        }

        else if (sexo == 'F' || sexo == 'f')
        {
            salariosMulheres += salario;
        }
        printf("Deseja continuar o progrma?\n 1. Sim \n 2. Não\n");
        scanf("%i", &verifica);

    }

    printf("Total de salarios dos homens: R$ %.2lf \n Total de salarios das mulheres: R$ %.2lf", salariosHomens, salariosMulheres);

    return 0;
}
