/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
 
    int n1;


    
    printf("Digite um número");
    scanf("%i", &n1);
    

    
    if (n1%2 == 0){
        printf("O Número é par!");
    } else{
        printf("O número é impar");
    }
    

}