#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>


int main()
{

    system("cls");
    srand(time(NULL));

    int numero, contagem, acimaDeCinco, DivisivelPorTres;

    acimaDeCinco = 0;
    contagem = 0;
    DivisivelPorTres = 0;

    while (contagem < 20)
    {
        numero = rand() % 11;
        printf("Numero sorteado: %i \n", numero);

        if(numero>5){
            acimaDeCinco++;
        }

        if(numero%3==0){
            DivisivelPorTres++;
        }
        contagem++;
    }

    printf("Numeros acima de 5: %i \n", acimaDeCinco);
    printf("Numeros divisiveis por 3: %i \n", DivisivelPorTres);
    

}