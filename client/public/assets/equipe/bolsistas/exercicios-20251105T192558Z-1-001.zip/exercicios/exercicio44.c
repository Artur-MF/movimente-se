#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int inicio, limite, incremento;
    inicio = 0;
    printf("Digite um limite para a sequencia: ");
    scanf("%i", &limite);

    printf("Digite um inicio para a sequencia: ");
    scanf("%i", &inicio);

    printf("Digite um incremento para a sequencia: ");
    scanf("%i", &incremento);
    while (inicio <= limite)
    {
        printf("%i\n", inicio);
        inicio += incremento;
    }
    printf("Acabou");
}