#include <stdio.h>
#include <locale.h>

int main()
{
    int i, numeroAnterior, numeroAnteriorDois, numero;
    numeroAnterior = 1;
    numeroAnteriorDois = 0;

    printf("%i\n", numeroAnterior);
    {

        for (i = 1; i <= 10; i++)
        {

            numero = numeroAnterior + (numeroAnteriorDois);
            printf("%i\n", numero);
            numeroAnteriorDois = numeroAnterior;
            numeroAnterior = numero;
        }

        printf("FIM!");
    }
}