#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>

int main()
{

    system("cls");
    srand(time(NULL));

    int contagem, media, idade, MaisDe18Anos, MenosDe5Anos, maior;

    contagem = 1;
    MaisDe18Anos = 0;
    MenosDe5Anos = 0;


    printf("Digite a idade: ");
    scanf("%i", &idade);
    maior = idade;
    media = idade;

    while (contagem < 10)
    {
        contagem++;
        media += idade;
        printf("Digite a idade: ");
        scanf("%i", &idade);
        if (maior < idade)
        {
            maior = idade;
        }

        if (idade >= 18)
        {
            MaisDe18Anos++;
        }

        else if (idade < 5)
        {
            MenosDe5Anos++;
        }
    }

    printf("Maior de idade: %i \n", maior);
    printf("Media de idade: %i \n", (media / 10));
    printf("Pessoas com Mais de 18 anos: %i \n", MaisDe18Anos);
    printf("Pessoas com Menos de 5 anos: %i \n", MenosDe5Anos);
}