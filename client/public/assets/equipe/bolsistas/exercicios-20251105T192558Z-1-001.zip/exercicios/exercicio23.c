/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char nome [50];
    char sexo [1];

    double total, valor;
    
    printf("Digite seu nome: ");
    scanf("%49[^\n]", nome);
    
    printf("Digite seu sexo [F/M]: ");
    scanf("%1s", sexo);
    
    printf("Digite o valor da compra: ");
    scanf("%lf", &valor);
    


    if (strcmp(sexo, "F") == 0){
        total = valor-(valor*0.13);
        printf("O Valor com desconto aplicado é: %lf", total);
    } else if(strcmp(sexo, "F") == 0){
        total = valor-(valor*0.05);
        printf("O Valor com desconto aplicado é: %lf", total);
    }
    
}