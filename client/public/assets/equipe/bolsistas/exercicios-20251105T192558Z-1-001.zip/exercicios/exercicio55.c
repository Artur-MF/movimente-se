
#include <stdio.h>
#include <stdlib.h>


int main()
{


    int jogador, sorteio, contador;
    sorteio = rand() % 10 + 1;
    contador = 0;


    while (contador < 4){
    printf("Digite um número para acertar o número sorteado: \n");
    scanf("%i", &jogador);
    
    if (jogador == sorteio){
        printf("Acertou!\n");
        break;
    } else{
        printf("Errou!\n");
    }
    contador++;
}

    


}