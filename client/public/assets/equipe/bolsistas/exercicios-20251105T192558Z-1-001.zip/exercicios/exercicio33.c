/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>


int main()
{

    double valorCasa, salario, prestacaoMensal;
    int anos;


    printf("Digite o valor da casa: R$ ");
    scanf("%lf", &valorCasa);

    printf("Digite o salário: R$ ");
    scanf("%lf", &salario);

    printf("Digite em quantos anos deseja pagar: ");
    scanf("%d", &anos);


    int totalMeses = anos * 12;
    prestacaoMensal = valorCasa / totalMeses;


    double limite = salario * 0.30;

    printf("\nPrestação mensal: R$ %.2lf\n", prestacaoMensal);
    printf("30%% do salário: R$ %.2lf\n", limite);


    if (prestacaoMensal <= limite) {
        printf("Empréstimo APROVADO!\n");
    } else {
        printf("Empréstimo NEGADO! Prestação excede 30%% do salário.\n");
    }



}