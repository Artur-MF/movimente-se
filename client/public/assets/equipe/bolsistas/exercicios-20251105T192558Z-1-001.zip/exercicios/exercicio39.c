#include <stdio.h>
#include <locale.h>

int main(){
    int contagem;
    contagem = 10;
    while(contagem>2){
        printf("%i\n", contagem);
        contagem--;
    }
    printf("Acabou");
}