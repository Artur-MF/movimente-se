#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int contagem, numeros, pares, impares;

    pares = 0;
    impares = 0;
    contagem = 0;


    while (contagem < 6)
    {
        printf("Digite um numero:");
        scanf("%i", &numeros);
        if (numeros % 2 == 0)
        {
            pares++;
        }
        else
        {
            impares++;
        }

        contagem += 1;
    }
    printf("A quantidade de números pares é: %i\n impares: %i", pares, impares);
}