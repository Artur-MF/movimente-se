/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/



#include <stdio.h>
#include <string.h>

int main() {
    char tipo[10];
    int dias;
    double km, preco;

    printf("Tipo de carro (popular/luxo): ");
    scanf("%9s", tipo);
    printf("Quantidade de dias: ");
    scanf("%d", &dias);
    printf("Quantidade de km percorridos: ");
    scanf("%lf", &km);

    if (strcmp(tipo, "popular") == 0) {
        preco = dias * 90;
        if (km <= 100) {
            preco += km * 0.20;
        } else {
            preco += km * 0.10;
        }
    } else if (strcmp(tipo, "luxo") == 0) {
        preco = dias * 150;
        if (km <= 200) {
            preco += km * 0.30;
        } else {
            preco += km * 0.25;
        }
    } else {
        printf("Tipo de carro inválido.\n");
        return 1;
    }

    printf("Preço total a pagar: R$ %.2lf\n", preco);

}