#include <stdio.h>

int main() {
    int numero, soma = 0;
    
    while (1) {
        printf("Digite um número (ou 1111 para parar): ");
        scanf("%i", &numero);
        
        if (numero == 1111) {
            break;
        }
        
        soma += numero;
    }
    
    printf("O somatório dos números digitados é: %d\n", soma);

    return 0;
}
