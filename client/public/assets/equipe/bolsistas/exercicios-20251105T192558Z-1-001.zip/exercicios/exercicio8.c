/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double n1;
    
    printf("Digite um valor em metros: \n");
    scanf("%lf", &n1);

    printf("A distância de %lf metros corresponde a:\n", n1);
    printf("  %.5lf Km\n", n1 * 0.001);
    printf("  %.5lf Hm\n", n1 * 0.01);
    printf("  %.5lf Dam\n", n1 * 0.1);
    printf("  %.5lf dm\n", n1 * 10);
    printf("  %.5lf cm\n", n1 * 100);
    printf("  %.5lf mm\n", n1 * 1000);



    return 0;
    
}