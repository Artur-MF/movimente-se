/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{
    #include <stdio.h>


    char nome[50];
    double salario, novo_salario;
    int anos;


    printf("Digite o nome do funcionário: ");
    scanf("%49[^\n]", nome);


    printf("Digite o salário atual: ");
    scanf("%lf", &salario);


    printf("Digite o número de anos que trabalha na empresa: ");
    scanf("%d", &anos);


    if (anos < 3) {
        novo_salario = salario + (salario * 0.03);
    } else if (anos < 10) {
        novo_salario = salario + (salario * 0.125);
    } else {
        novo_salario = salario + (salario * 0.20);
    }


    printf("\nFuncionário: %s\n", nome);
    printf("Salário antigo: R$ %.2lf\n", salario);
    printf("Novo salário: R$ %.2lf\n", novo_salario);





    
}