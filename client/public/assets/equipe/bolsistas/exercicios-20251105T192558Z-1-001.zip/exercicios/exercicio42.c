#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int contagem, limite;
    contagem = 0;
    printf("Digite um limite para a sequencia: ");
    scanf("%i", &limite);
    while (contagem <= limite)
    {
        printf("%i\n", contagem);
        contagem++;
    }
    printf("Acabou");
}