#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main()
{

    system("cls");

    int somatorio, numeros, contagem;

    somatorio = 0;

    while (contagem < 6)
    {
        printf("Digite um numero:");
        scanf("%i", &numeros);
        somatorio += numeros;
        contagem++;
    }
    printf("O Somatorio é: %i", somatorio);
}