#include <stdio.h>

int main() {
    int idade, totalIdades, numeroAlunos;
    double mediaIdade;

    idade = 0;
    totalIdades = 0;
    numeroAlunos = 0;

    while (1) {
        printf("Digite a idade do aluno (999 para parar): ");
        scanf("%i", &idade);

        if (idade == 999) {
            break;
        }

        totalIdades += idade;
        numeroAlunos++;
    }

    if (numeroAlunos > 0) {
        mediaIdade = totalIdades / numeroAlunos;
        printf("Total de alunos: %d\n", numeroAlunos);
        printf("Média de idade: %.2lf\n", mediaIdade);
    } else {
        printf("Nenhuma idade foi registrada.\n");
    }

    return 0;
}
