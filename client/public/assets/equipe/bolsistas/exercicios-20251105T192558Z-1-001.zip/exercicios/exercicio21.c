/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
 
    int ano;


    
    printf("Digite um ano");
    scanf("%i", &ano);
    

    
    if (ano%4 == 0 && ano%100 != 0){
        printf("O ano é bissexto!");
    } 
    else if (ano%100 == 0 && ano%400 == 0 ){
        printf("O ano é bissexto");
    } else{
        printf("O Ano não é bissexto!");
    }
    

}