#include <stdio.h>
#include <locale.h>

int main()
{
    int i, numero;
    printf("Digite um número: ");
    scanf("%i", &numero);

    if (numero > 0)
    {

        for (i = 1; i <= numero; i++)
        {
            printf("%i\n", i);
        }

        printf("FIM!");
    }
}