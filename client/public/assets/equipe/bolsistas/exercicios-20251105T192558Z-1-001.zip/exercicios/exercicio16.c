/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <stdio.h>

int main()
{
    double  dias, anos, total;
    int dias_perdidos;
    
    
    printf("Digite há quantos anos o a pessoa fuma:\n");
    scanf("%lf", &anos);
    
    printf("Digite quantos cigarros por dia a pessoa fuma:\n");
    scanf("%lf", &dias);
    
    total = (dias*(anos*365.6));
    
    dias_perdidos = (total*10)/1440;
    
    

    
    printf("Esse fumante já perdeu um total de %.2i dias de vida", dias_perdidos);
    
    




    return 0;
    
}