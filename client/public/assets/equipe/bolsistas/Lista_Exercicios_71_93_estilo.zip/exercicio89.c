#include <stdio.h>

int main() {
    int m[5][5];
    int i, j, soma = 0;

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 5; j++) {
            printf("Digite o elemento [%i][%i]: ", i, j);
            scanf("%i", &m[i][j]);
        }
    }

    for(i = 0; i < 5; i++) {
        soma += m[i][i];
    }

    printf("Soma diagonal principal: %i\n", soma);
    return 0;
}