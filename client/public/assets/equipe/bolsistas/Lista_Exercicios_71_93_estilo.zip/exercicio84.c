#include <stdio.h>

int main() {
    int a[5], b[5];
    int i;

    for(i = 0; i < 5; i++) {
        printf("Digite o %iº elemento: ", i + 1);
        scanf("%i", &a[i]);
    }

    for(i = 0; i < 5; i++) {
        b[i] = a[4 - i];
    }

    printf("Vetor invertido:\n");
    for(i = 0; i < 5; i++) {
        printf("%i ", b[i]);
    }
    printf("\n");
    return 0;
}