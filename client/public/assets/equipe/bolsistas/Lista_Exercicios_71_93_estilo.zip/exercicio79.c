#include <stdio.h>

int main() {
    int vetor[10];
    int i;

    for(i = 0; i < 10; i++) {
        printf("Digite o %iº numero: ", i + 1);
        scanf("%i", &vetor[i]);
    }

    printf("\nNumeros pares e suas posicoes:\n");
    for(i = 0; i < 10; i++) {
        if(vetor[i] % 2 == 0) {
            printf("Posicao %i: %i\n", i, vetor[i]);
        }
    }
    return 0;
}