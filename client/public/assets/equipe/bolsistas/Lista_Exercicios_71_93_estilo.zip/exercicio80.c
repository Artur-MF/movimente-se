#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int vetor[30];
    int i, chave, cont = 0;

    srand(time(NULL));
    for(i = 0; i < 30; i++) {
        vetor[i] = rand() % 15 + 1;
    }

    printf("Digite a chave a ser procurada: ");
    scanf("%i", &chave);

    printf("\nVetor gerado:\n");
    for(i = 0; i < 30; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n\nChave encontrada nas posicoes:\n");
    for(i = 0; i < 30; i++) {
        if(vetor[i] == chave) {
            printf("%i ", i);
            cont++;
        }
    }
    printf("\nA chave apareceu %i vezes.\n", cont);
    return 0;
}