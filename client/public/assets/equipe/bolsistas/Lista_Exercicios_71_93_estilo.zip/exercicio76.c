#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int vetor[7];
    int i;

    srand(time(NULL));
    for(i = 0; i < 7; i++) {
        vetor[i] = rand() % 100;
    }

    for(i = 0; i < 7; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}