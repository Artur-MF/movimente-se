#include <stdio.h>

int main() {
    int vetor[10];
    int i;

    for(i = 0; i < 10; i++) {
        if(i % 2 == 0) vetor[i] = 5;
        else vetor[i] = 3;
    }

    for(i = 0; i < 10; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}