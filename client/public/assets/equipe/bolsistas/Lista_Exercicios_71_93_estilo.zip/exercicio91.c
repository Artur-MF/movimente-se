#include <stdio.h>

int main() {
    int m[3][3];
    int i, j, maior, li = 0, cj = 0;

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            printf("Digite o elemento [%i][%i]: ", i, j);
            scanf("%i", &m[i][j]);
            if(i == 0 && j == 0) maior = m[i][j];
            if(m[i][j] > maior) {
                maior = m[i][j];
                li = i; cj = j;
            }
        }
    }

    printf("%i %i %i\n", maior, li, cj);
    return 0;
}