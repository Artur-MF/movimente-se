#include <stdio.h>

int main() {
    char nomes[7][50];
    int i;

    for(i = 0; i < 7; i++) {
        printf("Digite o nome da pessoa %i: ", i + 1);
        scanf("%49s", nomes[i]);
    }

    printf("\nNomes na ordem inversa:\n");
    for(i = 6; i >= 0; i--) {
        printf("%s\n", nomes[i]);
    }
    return 0;
}