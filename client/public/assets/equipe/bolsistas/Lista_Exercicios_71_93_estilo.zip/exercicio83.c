#include <stdio.h>

int main() {
    double vetor[12];
    int i;
    double soma = 0.0;

    for(i = 0; i < 12; i++) {
        printf("Digite a nota %i: ", i + 1);
        scanf("%lf", &vetor[i]);
        soma += vetor[i];
    }

    printf("Media: %.2lf\n", soma / 12.0);
    return 0;
}