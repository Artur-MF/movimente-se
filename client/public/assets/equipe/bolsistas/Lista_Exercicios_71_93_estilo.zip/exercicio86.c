#include <stdio.h>

int main() {
    int m[3][3];
    int i, j;

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            printf("Digite o elemento [%i][%i]: ", i, j);
            scanf("%i", &m[i][j]);
        }
    }

    printf("\nMatriz transposta:\n");
    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            printf("%i ", m[j][i]);
        }
        printf("\n");
    }
    return 0;
}