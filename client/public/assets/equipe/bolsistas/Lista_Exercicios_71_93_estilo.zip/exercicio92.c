#include <stdio.h>

int main() {
    int a[3][3], b[3][3], c[3][3];
    int i, j;

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            printf("Digite A[%i][%i]: ", i, j);
            scanf("%i", &a[i][j]);
        }
    }

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            printf("Digite B[%i][%i]: ", i, j);
            scanf("%i", &b[i][j]);
        }
    }

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            c[i][j] = a[i][j] + b[i][j];
            printf("%i ", c[i][j]);
        }
        printf("\n");
    }
    return 0;
}