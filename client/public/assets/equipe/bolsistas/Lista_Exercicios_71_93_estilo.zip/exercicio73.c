#include <stdio.h>

int main() {
    int vetor[10];
    int i, valor = 9;

    for(i = 0; i < 10; i++) {
        vetor[i] = valor--;
    }

    printf("Vetor gerado:\n");
    for(i = 0; i < 10; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}