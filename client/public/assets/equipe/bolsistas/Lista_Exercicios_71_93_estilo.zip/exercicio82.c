#include <stdio.h>

int main() {
    int vetor[20];
    int i, maior, menor;

    for(i = 0; i < 20; i++) {
        printf("Digite o %iº numero: ", i + 1);
        scanf("%i", &vetor[i]);
        if(i == 0) {
            maior = menor = vetor[i];
        } else {
            if(vetor[i] > maior) maior = vetor[i];
            if(vetor[i] < menor) menor = vetor[i];
        }
    }

    printf("Maior: %i\n", maior);
    printf("Menor: %i\n", menor);
    return 0;
}