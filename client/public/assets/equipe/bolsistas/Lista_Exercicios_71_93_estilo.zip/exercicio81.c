#include <stdio.h>

int main() {
    int vetor[10];
    int i;

    for(i = 0; i < 10; i++) {
        printf("Digite o %iº numero: ", i + 1);
        scanf("%i", &vetor[i]);
    }

    printf("\nVetor na ordem inversa:\n");
    for(i = 9; i >= 0; i--) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}