#include <stdio.h>

int main() {
    int vetor[10];
    int i, pal = 1;

    for(i = 0; i < 10; i++) {
        printf("Digite o %iº elemento: ", i + 1);
        scanf("%i", &vetor[i]);
    }

    for(i = 0; i < 5; i++) {
        if(vetor[i] != vetor[9 - i]) {
            pal = 0;
            break;
        }
    }

    if(pal) printf("1\n");
    else printf("0\n");
    return 0;
}