#include <stdio.h>

int main() {
    int n = 3;
    int m[3][3];
    int i, j, sim = 1;

    for(i = 0; i < n; i++) {
        for(j = 0; j < n; j++) {
            printf("Digite o elemento [%i][%i]: ", i, j);
            scanf("%i", &m[i][j]);
        }
    }

    for(i = 0; i < n; i++) {
        for(j = 0; j < n; j++) {
            if(m[i][j] != m[j][i]) sim = 0;
        }
    }

    if(sim) printf("1\n");
    else printf("0\n");
    return 0;
}