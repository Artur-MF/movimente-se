#include <stdio.h>

int main() {
    int m[3][4];
    int i, j, soma;

    for(i = 0; i < 3; i++) {
        soma = 0;
        for(j = 0; j < 4; j++) {
            printf("Digite o elemento [%i][%i]: ", i, j);
            scanf("%i", &m[i][j]);
            soma += m[i][j];
        }
        printf("Soma da linha %i: %i\n", i, soma);
    }
    return 0;
}