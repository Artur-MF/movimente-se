#include <stdio.h>

int main() {
    int vetor[15];
    int i;

    for(i = 0; i < 15; i++) {
        printf("Digite o %iº numero: ", i + 1);
        scanf("%i", &vetor[i]);
    }

    printf("\nNumeros digitados:\n");
    for(i = 0; i < 15; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n\nMultiplos de 10:\n");
    for(i = 0; i < 15; i++) {
        if(vetor[i] % 10 == 0) {
            printf("Posicao %i: %i\n", i, vetor[i]);
        }
    }
    return 0;
}