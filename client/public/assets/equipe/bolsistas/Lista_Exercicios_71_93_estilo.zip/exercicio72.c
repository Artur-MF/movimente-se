#include <stdio.h>

int main() {
    int vetor[10];
    int i;

    for(i = 0; i < 10; i++) {
        vetor[i] = (i + 1) * 5;
    }

    printf("Vetor gerado:\n");
    for(i = 0; i < 10; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}