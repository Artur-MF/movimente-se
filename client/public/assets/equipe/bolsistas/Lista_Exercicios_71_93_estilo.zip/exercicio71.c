#include <stdio.h>

int main() {
    int vetor[8];
    int i;

    for(i = 0; i < 8; i++) {
        vetor[i] = 999;
    }

    printf("Vetor gerado:\n");
    for(i = 0; i < 8; i++) {
        printf("%i ", vetor[i]);
    }
    printf("\n");
    return 0;
}